#pragma once

#ifndef _FUZZYMODEL_H_
#define _FUZZYMODEL_H_
#include "model.h"
class FuzzyModel : public model
{


public:
	FuzzyModel();
	~FuzzyModel();
};

#endif