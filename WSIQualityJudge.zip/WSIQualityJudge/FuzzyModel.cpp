#include "FuzzyModel.h"



FuzzyModel::FuzzyModel()
{
}


FuzzyModel::~FuzzyModel()
{
}
